## Aufgabe 1
Durchschnitt (Mittelwert):
* Der Durchschnitt wird berechnet, indem man alle Werte in einer Datenreihe addiert und das Ergebnis durch die Anzahl der Werte teilt.

Median:
* Der Median ist der mittlere Wert in einer sortierten Datenreihe.
* Wenn die Datenreihe ungerade ist, ist der Median der Wert in der Mitte. Wenn die Datenreihe gerade ist, ist der Median der Durchschnitt der beiden mittleren Werte.
* Der Median ist robust gegenüber Ausreißern, da er nicht von extremen Werten beeinflusst wird.

l2-Loss (quadratischer Verlust. Ridge Regression):
* Der l2-Loss misst die quadratische Differenz zwischen den vorhergesagten und tatsächlichen Werten.

l1-Loss (absoluter Verlust, Lasso-Regression):
* Der l1-Loss misst die absolute Differenz zwischen den vorhergesagten und tatsächlichen Werten.

## Aufgabe 2
Eine konvexe Funktion ist eine Funktion, die unterhalb zweier verbundener Punkte von ihr verläuft (s. Bild). Daher kann es nur ein globales Minimum geben.
![Beispiel einer konvexen Funktion](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Convex_function.svg/1280px-Convex_function.svg.png)


## Aufgabe 3

## Aufgabe 4
Die Huber Regression overfittet bei eingen Datensets weniger als die Linear Regression bzw. die Huber Regression is robuster gegen Ausreißer als die Linear Regression.